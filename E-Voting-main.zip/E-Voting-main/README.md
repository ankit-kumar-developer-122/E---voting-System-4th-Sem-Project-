Requirements:- 
      1)  opencv-python
      2)  scikit-learn
      3)  pywin32
